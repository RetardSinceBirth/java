package pack1;

import java.util.Scanner;

public class Welcome
{
	static void test()throws Exception
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("WELCOME BTO BANK");
		System.out.println("SELECT 1-NEW USERS");
		System.out.println("SELECT 2-EXISTING USERS");
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:
			NewUser.information();
			break;
//		case 2:
			
		}
	}
	public static void main(String[] args)throws Exception
	{
		test();
	}
}
