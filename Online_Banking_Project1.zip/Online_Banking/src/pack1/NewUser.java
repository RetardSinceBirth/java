package pack1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class NewUser
{
	static boolean test(String email)
	{
		String EMAIL_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
			      String email1 =email;
			      Boolean b = email1.matches(EMAIL_REGEX);
			return b;    
			      
	}
	public static void information()throws Exception
	{
		int flag = 1;
		System.out.println("OPEN YOUR ACCOUNT");
		Message msg = Message.getInstance();
		EncryptDecrypt EncDec = new EncryptDecrypt();
		BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
		String choice=null;
		do
		{
			
			System.out.println("ENTER USER NAME");
			String username=sc.readLine();
			System.out.println("ENTER FIRST  NAME");
			String firstname=sc.readLine();
			System.out.println("ENTER LAST NAME");
			String lastname=sc.readLine();
			System.out.println("ENTER DATE OF BIRTH(DD-MM-YYYY)");
			String dob=sc.readLine();
			System.out.println("ENTER EMAIL ID");
			String email;
			while(true)
			{
				email=sc.readLine();
				Boolean validEmail=test(email);
				if(validEmail)
				{
					break;
				}else
				{
					System.out.println("Invalid Email id");
					//msg.printMsg("Invalid Email id");
					System.out.println("PLEASE ENTER CORRECT EMAIL");
				}
			}
			System.out.println("ENTER CONTACT");
			String contact=sc.readLine();
			System.out.println("ENTER ADDRESS");
			String address=sc.readLine();
			String value=Security.question();
			String value1[]= value.split("/");
			String question=value1[0];
			String answer=value1[1];
			String psw = "";
			while(flag == 1){
				System.out.println("Password Specifications: ");
				System.out.println("Your password should contain atleast one uppercase character");
				System.out.println("Your password should contain atleast one digit");
				System.out.println("Your password should contain atleast one lowercase character");
				System.out.println("Your password should contain atleast one special symbol");
				System.out.println("Your password length should be between 6 to 20 characters");
				System.out.println("ENTER PASSWORD");
				String password=sc.readLine();
				PasswordValidator pswvld = new PasswordValidator();
				boolean correct = pswvld.validate(password);
				if(correct){
					psw = EncDec.encrypt(password);
					System.out.println("PLEASE RETYPE PASSWORD");
					String Rpassword=sc.readLine();
					if(password.equals(Rpassword)){
						flag++;
						break;
					}
					else{
						System.out.println("Wrong password. Kindly type correct password");
					}
				}
				else{
					System.out.println("Your password does not follow specifications.");
				}
				
			}
			
			flag = 0;
			System.out.println("If You Want To Insert More Element then 'yes' Else 'No' ");
			choice=sc.readLine();
			InsertNewUser in = new InsertNewUser(contact,email,firstname,lastname,username,dob,address,question,answer,psw);
			
			
			while(flag == 0){
				RandomGenerator rg = new RandomGenerator();
				int accN = rg.GenAccNum();
				int Otp = rg.GenOtp();
				SimpleMailDemo Mail = new SimpleMailDemo(email, "Account Verification", "Hi '"+ firstname  +"' Your account has been created successfully. ", Otp);
				System.out.println("Provide the OTP sent to your mail : ");
				int Input = Integer.parseInt(sc.readLine());
				if(Input == Otp){
					in.Insert();
					
					System.out.println("Your registration has been done successfully!" + " Your Account No is: "+ accN);
					flag++;
					
				}
				
				else{
					System.out.println("you provided wrong OTP");
					
				}
			}
		}while("yes".equalsIgnoreCase(choice));
	}
}
