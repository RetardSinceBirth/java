package pack1;

import java.sql.*;
import java.util.*;

public class Login
{
	static Connection con;

	public static void main(String[] args) throws Exception{

		/**
		 * Calling the connection class and establishing it
		 */
		int flag = 0;
		/**
		 * USING CONNECTION STATEMENT FOR CONNECTION CLASS
		 */
		
			con = DbConnection.getConnection();
		
		Statement st;
		
		st = con.createStatement();

		Scanner scan = new Scanner(System.in);
		do 
		{

			/**
			 * GETTING THE USERID AND VALIDATING THE USER
			 */
			System.out.println("Enter the User_ID");
			String User_Id = scan.next();
			String user_check = "select User_Id from user_detail where User_Id='"+ User_Id + "'";

			ResultSet rs1, rs, rs2;
			
			rs1 = st.executeQuery(user_check);
			
			if (rs1.next()) {

				/**
				 * CHECKING FOR ALREADY LOGGED IN USER AND CHECKING WHETHER
				 * ACCOUNT IS ACTIVE
				 */
				String isActiveCheck = "select * from Account where user_id='"+ User_Id + "' and isactive=1 and isloggedin=0";
			
				rs2 = st.executeQuery(isActiveCheck);
					if (rs2.next()) {
						/**
						 * GETTING PASSWORD AN VALIDATING IT
						 */

						Scanner s = new Scanner(System.in);
						System.out.println("Enter the Password");
						String User_Password = s.next();

						String login_check = "select password from user_detail where user_id='"+ User_Id + "'";

						rs = st.executeQuery(login_check);
						int count;
						while (rs.next()) {

							String name1 = rs.getString("password");
							for (count = 0; count < 2; count++) {  //ALLOWS TO ENTER PASSWORD FOR 2 TIMES
								if (name1.equals(User_Password)) {

									/**
									 * SUCCESS LOGIN LOOP
									 */
									flag = 1;
									System.out.println("Success");
									String update_isloggedin = "Update Account set isloggedin = 1 where user_id='"
											+ User_Id + "'";
									st.executeQuery(update_isloggedin);

									break;
								}

								else {
									/**
									 * RETRYING PASSWORD BLOCK
									 */
									System.out
											.println("Enter the Password Again(Tries left=)"
													+ (2 - count));
									User_Password = scan.next();
								}
							}
							if (count == 2) {
								/**
								 * SENDING MAIL AND BLOCKING THE ACCOUNT
								 */
								String update_inactive = "Update Account set isActive= 0 where User_Id='"+ User_Id + "'";
								st.executeQuery(update_inactive);
							}
						}
					}

					else {

						/**
						 * REACHES HERE IF A USER IS ALREADY LOGGED IN OR HIS ACCOUNT IS INACTIVE
						 */
						System.out.println("Account Inactive Or Already Logged In");

					}
				} 
			 else {
				/**
				 * REACHES HERE IF USER ENTERS AN INVALID USER_ID
				 */
				System.out.println("invalid user");
			}
		} while (flag == 0);//THIS HELPS TO ENTER THE USERID REPEATEDLY IF USER ENTER A WRONG USER_ID
	}

}

